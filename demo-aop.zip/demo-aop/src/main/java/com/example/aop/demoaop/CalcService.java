package com.example.aop.demoaop;

public interface CalcService {
	
	int add(int a, int b);

}
